<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/preloader.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/gallery.css')); ?>">
    
    <script src="<?php echo e(asset('js/preload.js')); ?>"></script>
</head>

<body>
    <div class="gallery" id="gallery">
        <div class="image-gallery" id="imageGallery">

        </div>
        <div class="video-gallery" id="videoGallery">

        </div>
    </div>
    <div class="preloader-container" id="preloaderContainer">
        <div class="explore-buttons-panel" id="explorePanel">
            <div class="image-part" id="imagePart">
                <h4 id="btnImageExplore">Photography</h4>
            </div>
            <div class="video-part" id="videoPart">
                <h4 id="btnImageExplore" id="btnVideoExplore">Videography</h4>
            </div>
        </div>
        <div class="preloader-bar" id="preloaderBar">
            <div class="preloader-icon" id="preloaderIcon">
                <img class="preloader-icon-img" id="preloaderIconImage" src="<?php echo e(asset('images/turtule.png')); ?>"
                    alt="turtule">
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\pet-projects\show-case\resources\views/home.blade.php ENDPATH**/ ?>